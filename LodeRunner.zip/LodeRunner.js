/*     Lode Runner

Aluno 1: 55045 David Antunes
Aluno 2: 55797 Daniel Joao

Comentario:

Foi Feito tudo

01234567890123456789012345678901234567890123456789012345678901234567890123456789
*/


// GLOBAL VARIABLES

// tente nÃ£o definir mais nenhuma variÃ¡vel global

let empty, hero, control;



// ACTORS

class Actor {
	constructor(x, y, imageName) {
		this.x = x;
		this.y = y;
		this.imageName = imageName;
		this.show();
		// Name of the Type of actor
		this.name = "";
		this.visible=true;
	}
	
	draw(x, y) {
		control.ctx.drawImage(GameImages[this.imageName],
				x * ACTOR_PIXELS_X, y* ACTOR_PIXELS_Y);
	}
	move(dx, dy) {
		this.hide();
		this.x += dx;
		this.y += dy;
		this.show();
	}
}

class PassiveActor extends Actor {
	constructor(x, y, imageName) {
		super(x, y, imageName);
		//tells if the object serves as a horizontal path
		this.moveOnX= false; 
		//tell is the object serves as a vertical path
		this.moveOnY=false; 
		//tells if the active actor can move horizontally inside the object
		this.moveOnUnder=false; 
		//tells if this object can be eaten, if it can serve as gold
		this.eatable = false;
		// tells if this object can be passed through in any direction, 
		//example: chimey, destroyed blocks,  food
		this.passthrough = false;
		//tell is the object can be destroyed in the game
		this.destroyable = false;
		//tells if the object serves as a winning object
		this.winObject = false; 
		//tells if the object is destroyed
		this.destroyed = false;

		// Name of the Type of actor. This is here because the image can 
		//be change but its behaviour not
		this.name = "";

		//tells if the object is displayed
		this.visible = true;

		//tell if this actor allows the actor above him to shoot
		this.canShootStandingOnMe = false;
	}

	//the actor must not shoot
	getCanShootStandingOnMe() {
		return this.canShootStandingOnMe;
	}
	//Returns if the object is an solidObject aka cant be passthrough 
	hardObject() {
		return false;
	}

	show() {
		control.world[this.x][this.y] = this;
		this.draw(this.x, this.y);
		this.visible=true;
	}
	hide() {
		control.world[this.x][this.y] = empty;
		empty.draw(this.x, this.y);
		this.visible=false;
	}

	animation(){

	}
}

class ActiveActor extends Actor {
	constructor(x, y, imageName) {
		super(x, y, imageName);
		this.time = 0;	// timestamp used in the control of the animations

		//Tells if the actor is a good actor or not
		this.good = false;

		//Tells which direction the actor is facing
		this.direction = [0,0]; 
	}
	/**
	 * finds a random place in the map to place the object obj
	 * @param {} obj 
	 */
	findRandomPos(obj){
		let co  = true;
		let xx = 0;
		let yy = 0;
		let newA = null;
		while(co){
			xx = rand(WORLD_WIDTH);
			yy = rand(WORLD_HEIGHT);
			newA = control.getObject(xx,yy);
			if(newA==empty){
				co = false;
			}
		}
		newA = obj;
		newA.x = xx;
		newA.y = yy;
		newA.show();
	}

	//responsible for the actor to pick up food
	collect(){}

	/**
	 * Responsible to make the actor fall one step
	 * actor only falls one move down if they are on a passthrough (empty object) 
	 * and down is also an empty object or if the object is movedOnUnder
	 */
	actorFall(){

		let res= false;
		let yy = this.y+1;
		
		
		let downActiveActor = control.getActiveObject(this.x,yy);

			let  downObject = control.getPassiveObject(this.x,yy);
			let passiveBlock = control.getPassiveObject(this.x,this.y);

			if(downActiveActor!=empty){
				res=false;
			}
			else if(passiveBlock.passthrough){
				if(downObject !=null && (downObject.passthrough || downObject.moveOnUnder)){
					this.move(0,1);
					res = true;
				}
			}
		
		return res;
	}

	// ANimation of the actor
	animation(dx,dy){
		let xx = this.x+dx;
		let yy = this.y+dy;


		let next = control.getPassiveObject(xx,yy);
		
		let currentBlock = control.getPassiveObject(this.x,this.y);
		
		//check if they can move
		if(next==control.boundary){
			return;
		}

		if(dy==-1){

			//If the current block lets you move vertically
			if(!currentBlock.moveOnY){
				return;
			}
		//if the actor is on a vertical object and decides to move up, it only happens if the up
		//object is a vertical path or (can be penetrated and is not destroyed)
			if(!next.hardObject() && currentBlock != empty && !currentBlock.destroyed 
			&& (currentBlock.moveOnY || next.passthrough)){
				this.move(dx,dy);
			}
			return;
		}

		//if the next object can be passthroughed
		if (next.passthrough){
			if(dy==0){
				this.move(dx,dy);
			}else if(dy==1){
				//actor wants to fall
				this.move(dx,dy);
			}
		}
		//if he wants to go down the vertical path
		else if(next.moveOnY){
			this.move(dx,dy);
		}
		//if he wants move inside the horizontal path
		else if(next.moveOnUnder){
			this.move(dx,dy);
		}
	}
	/*
		tells if the active actor is going left
	*/
	left()
	{
		if(this.direction[0] == -1)
			return true;
		return false;
	}
	/*
		tells if the active actor is going up
	*/
	up()
	{
		if(this.direction[1] == -1)
			return true;
		return false;
	}
	/*
		moves the actor and updates its direction
	*/
	move(dx, dy) {
		if(dx != 0){
			this.direction[0] = dx;
		}
		if(dy != 0){
		this.direction[1] = dy;
		}
		// Tries to collect Something in the next block
		this.collect(this.x + dx, this.y + dy);
		super.move(dx,dy);
		this.showAnimation();

	}
	show(){
		control.worldActive[this.x][this.y] = this;
		this.draw(this.x, this.y);
		this.visible=true;
	}
	hide() {
		control.worldActive[this.x][this.y] = empty;
		control.world[this.x][this.y].draw(this.x, this.y);
		this.visible=false;
	}


	//show the active actors pictures as they move
	showAnimation()
	{
		let curBlock = control.getPassiveObject(this.x,this.y);
		//let downActiveActor = control.getActiveObject(this.x,this.y+1);
		let groundBlock = control.getPassiveObject(this.x,this.y+1);

		if(groundBlock!=control.boundary){
			//se abaixo estiver um ator passivo, entao sai logo
			if(control.worldActive[this.x][this.y+1]!=empty){
				return;
			}
		}	
		//Name of the object
		let name = this.name;
		switch(curBlock.name)
					{
						case "ladder": 
							
							if(this.imageName == name + "_on_ladder_left")
								this.imageName = name + "_on_ladder_right";
							else if(this.imageName == name + "_on_ladder_right")
								this.imageName = name + "_on_ladder_left";
							else
							{
								if(this.left()) 
									this.imageName = name + "_on_ladder_left";
								else
									this.imageName = name + "_on_ladder_right";
							}
							
						break;
						case "empty":
							if((groundBlock!= empty  && !groundBlock.moveOnUnder 
								&& !groundBlock.destroyed))
							{
								if(this.left()) 
								this.imageName = name + '_runs_left';
								else
								this.imageName = name + '_runs_right';
							} 
							else 
							{
								if(this.left()) 
								this.imageName = name + '_falls_left';
								else
								this.imageName = name + '_falls_right';
							}

						break;

						case "rope":
							if(this.left()) 
								this.imageName = name + '_on_rope_left';
							else
								this.imageName = name + '_on_rope_right';	

						break;

						case "chimney":

							if(this.left()) 
								this.imageName = name + '_falls_left';
							else
								this.imageName = name + '_runs_right';	

						break;

						case "stone":

							if(this.left()) 
								this.imageName = name + '_runs_left';
							else
								this.imageName = name + '_runs_right';	

						break;

						case "brick":

							if(this.left()) 
								this.imageName = name + '_runs_left';
							else
								this.imageName = name + '_runs_right';	

						break;
					}
					this.show();
	}

}

class Brick extends PassiveActor {
	constructor(x, y) { super(x, y, "brick"); 
		super.moveOnX=true;
		this.destroyable =true;
		this.timer = 0;

		// If it is a solidBlock
		this.hard = true;
		super.canShootStandingOnMe = true;
		// Var that holds the timout function when the block is destroyed
		this.regen = null;
		this.name = "brick";
	}
		
	hide() 
	{
		clearTimeout = this.regen;
		super.hide();
	}


	destroyBlock()
	{
		//Mete o bloco invisivel
		if(this.destroyed){
			return;
		}
		// Transforms this block in an empty block
		this.hard = false;
		this.imageName = "empty";
		this.show();
		this.destroyed = true;
		this.passthrough = true;
		super.moveOnY = true;
		super.moveOnX = false;
		this.canShootStandingOnMe = false;
		
		this.regen = setTimeout(()=>
		{

			let active = control.worldActive[this.x][this.y];

			// If the active object is an enemy or a hero
			// it will deal with it
			if(active!=empty&&!active.good){
				active.reborn();
			}else if(active!=empty && active.good)
				control.gameLost();

			//Restores the block to being a block
			this.destroyed = false;
			this.imageName = "brick";
			this.passthrough = false;
			this.moveOnY = false;
			this.moveOnX = true;
			this.hard = true;
			this.canShootStandingOnMe = true;
			this.show();

		},9000);
	
	}
		
	hardObject()
	{
		return this.hard;
	}
}

class Chimney extends PassiveActor {
	constructor(x, y) { 
		super(x, y, "chimney");
		this.passthrough=true;
		this.name = "chimney";
	}
}

class Empty extends PassiveActor {
	constructor() { super(-1, -1, "empty");
	super.passthrough = true;
	this.name = "empty";	
}
	show() {}
	hide() {}
}

class Gold extends PassiveActor {
	constructor(x, y) { 
	super(x, y, "gold");
	super.eatable=true;
	super.passthrough=true;
	// Tells the program there is a new food in the map
	control.food++;
	this.name = "gold";
	}

	
	eaten()
	{
		super.hide();
	}

	//Asks if this gold can be droped in the given coordinates
	CanIDropU(x,y)
	{
		if(control.getPassiveObject(x,y).hardObject())
			return true;
		return false;
	}


	// Drops the gold in the given position
	drop(x,y)
	{
		this.x = x;
		this.y = y;
		this.show();
	}

	// Random drops the gold
	ForceDrop()
	{
		let dropped = false;
		while(!dropped)
		{
			let x = rand(WORLD_WIDTH);
			let y = rand(WORLD_HEIGHT);
			if(control.getPassiveObject(x,y) == empty 
			&& control.getPassiveObject(x,y + 1).hardObject())
			{
				this.drop(x,y);
				dropped = true;
			}
		}
	}

}

class Invalid extends PassiveActor {
	constructor(x, y) { super(x, y, "invalid"); }
}

class Ladder extends PassiveActor {
	constructor(x, y) {
		super(x, y, "ladder");
		super.moveOnY=true;
		this.hide();
		this.visible = false;
		this.canShootStandingOnMe=true;
		this.winObject = true;
		this.name = "ladder";
	}

    makeVisible() {
       this.imageName = "ladder";
      	this.name = "ladder";
		this.show();
		this.visible=true;
		
	}
}

class Rope extends PassiveActor {
	constructor(x, y) { super(x, y, "rope"); 
	super.moveOnUnder=true;
	this.name = "rope";
	}
}

class Stone extends PassiveActor {
	constructor(x, y) { 
		super(x, y, "stone");
		super.moveOnX=true;
		this.canShootStandingOnMe = true;
		this.name = "stone";
	}

	
	hardObject()
	{
		return true;
	}
}

// GAME CONTROL
class Boundary extends Stone {
	constructor()
	{
		super(-1,-1, "empty");
		this.moveOnX = false;
		this.canShootStandingOnMe=false;
		this.canShootStandingOnMe = true;
		
	}

	hardObject()
	{
		return true;
	}

	hide() {}

	show() {}

}

class Hero extends ActiveActor {
	constructor(x, y) {
		super(x, y, "hero_runs_left");

		this.good=true;
		this.name = 'hero';
		this.direction = [-1,0];
		this.eatable = true;
		// Number of golds eaten
		this.gold = 0;
	}

	animation() {
		// Apply Gravity
		if(this.actorFall()){
			return;
		}
		let k = control.getKey();
		if( k == ' ' ) { this.shoot(); return; }
		if(k == null)
			return;
		else
		{			
			let [dx, dy] = k;

			// Checks if there is a change in direction
			// If there is, changes it but the hero remains
			// in the same block
			if(dx != this.direction[0] && dx != 0)
			{
				this.direction[0] = dx;
				this.showAnimation();
				return;	
			}
			super.animation(dx,dy);
		}
	}
	

	/**
	 *  Shoots an adjacent block if the ground the hero is standing on is can hold a shot
	 *  If there is an hardObject in front the shoot will be cancelled
	 *  If the shoot is possible than the hero will suffer recoil
	 *  This recoil will be mitigated if the block behind him is a solid object
	 *  thus helping the hero witstanding the shot
	 */
	shoot()
	{


		let BlockToShoot = control.getPassiveObject(this.x + this.direction[0], this.y + 1);
		let BlockFrontHero = control.getPassiveObject(this.x + this.direction[0], this.y);
		let BlockBehindHero = control.getPassiveObject(this.x - this.direction[0], this.y);
		let GroundBehindHero = control.getPassiveObject(this.x - this.direction[0], this.y + 1);

		// If the ground behind can hold a shot
		if(!GroundBehindHero.getCanShootStandingOnMe()){
			return; 
		}
		// If the block in front is an hard block
		else if(BlockFrontHero.hardObject()){
			return; 
		}
		// If the block to be destroyed is destroyable or if it is already destroyed
		else if(!BlockToShoot.destroyable || BlockToShoot.destroyed)
		{
			return; 
		}
		else
		{
			
			// If the block behind is not a hard block
			// the hero will suffer recoil
			if(!BlockBehindHero.hardObject())
			{
				// moves the hero behind
				super.move(-this.direction[0], 0);
				
				// Since the move changes direction
				// We have to rechange it
				this.direction[0] = -this.direction[0];
			}

			// Loads the correct shooting image
			if(super.left())
			{
				this.imageName = this.name + "_shoots_left";
			}
			else
			{
				this.imageName = this.name + "_shoots_right";
			}

			super.show();
			// Destroys the block
			BlockToShoot.destroyBlock();
		}
	}

	// Collects the object in the given x and y
	// This method is only used before the hero moves
	collect(x,y){

		let nextActiveBlock = control.getActiveObject(x,y);

		// If the block is an enemy
		// Loses the game
		if(nextActiveBlock != empty && !nextActiveBlock.good)
		{
			control.gameLost();
		}

		let nextBlock = control.getPassiveObject(x,y);

		// If the block is eatable
		if(nextBlock.eatable){
			control.food--;
			this.gold++;
			nextBlock.hide();
		}
		control.checkGoldCollected();

	}
}

class Robot extends ActiveActor {
	constructor(x, y) {
		super(x, y, "robot_runs_right");
		this.name = 'robot';
		// Holds the gold till a certain time has passed
		this.tempFood=null;

		// The amount of time the gold is hold
		this.timeToDropFood = 15;
		// Timer that holds how many time the robot
		// has held the gold
		this.FoodTimer = 0;
		// Timer used to slow the robot down in animation
		this.sec = 0;
		this.direction[1,0];
		// Tells if the robot was trapped before
		this.wasTrapped = false;
		// Time spent inside a hole
		this.freeCount = 0;
	}

	/**moves the robot
	 * 
	 * @param {*} dx 
	 * @param {*} dy 
	 */
	
	move(dx,dy){
		let robotAhead = control.getActiveObject(this.x+dx,this.y+dy);
		
		// IF there is a robot ahead, the move is cancelled
		if(robotAhead == control.boundary || (robotAhead != empty &&!robotAhead.good)){ 
			return;
		}		
		super.move(dx,dy);
		// Tries to drop the food
		this.dropFood();
	}
	/**
	 * tells if the robot is trapped
	 */
	trapped()
	{
		let currentBlock = control.getPassiveObject(this.x,this.y);

		if(currentBlock.destroyed)
			return true;
		return false;
	}
	/**
	 * the robot tries to free itself after falling into a pit
	 */
	getOutOfHoleWhenTrapped(){
		if(this.trapped()){

			if(this.tempFood != null)
				this.ForceDropFood();

			let aboveActiveBlock = control.getActiveObject(this.x,this.y - 1);

			if(aboveActiveBlock != empty && !aboveActiveBlock.good)
				return;

			this.freeCount++;
			if(this.freeCount>9){
				this.move(0,-1);
				// Resets timers to move
				this.freeCount = 0;
				this.sec = 0;
				this.wasTrapped = true;
			}
		}
	}

	// Drops the gold if the robot is holding one
	dropFood(){

		if(this.tempFood == null)
			return;

		// Until the time has not passed the gold will not be dropped
		if(this.FoodTimer < this.timeToDropFood)
			this.FoodTimer++;
		// If it is not possible to drop the food the timer will receive a new time
		// and try again in the future
		else if(!this.tempFood.CanIDropU(this.x,this.y + 1))
			
			this.FoodTimer = rand(this.timeToDropFood);
		else
		{
			this.tempFood.drop(this.x,this.y);
			this.show();
			this.tempFood = null;
			this.FoodTimer = 0;
		}
	}

	// Forces the food to be dropped
	// This is used when a robot falls into the pit
	// Checks if the above block is empty
	// in that case the gold will be dropped there
	// if not possible
	// the gold will be sent to a random location
	ForceDropFood()
	{
		let currentBlock = control.getPassiveObject(this.x, this.y);
		let aboveBlock = control.getPassiveObject(this.x, this.y + 1);

		if(currentBlock.destroyed && aboveBlock != empty)
		{
			this.tempFood.ForceDrop();
		}else
		{
			this.tempFood.drop(this.x, this.y - 1);
		}
		this.tempFood = null;
		this.FoodTimer = 0;
	}

	
	/**
	 * if a robot is caught in a hole after it closes,
	 * this function makes sure of its return
	 */
	reborn(){
		control.worldActive[this.x][this.y]=empty;
		this.findRandomPos(this);
		this.freeCount=0;
	}

	/**
	 * gets the direction of the hero to be followed by the robot
	 */
	getHeroDir()
	{
		let dir = [0,0];
		if(this.x < hero.x)
			dir[0] = 1;
		else if(this.x > hero.x)
			dir[0] = -1;
		else{
			dir[0] = rand(1);
		}
		

		if(this.y < hero.y)
			dir[1] = 1;
		else if(this.y > hero.y)
			dir[1] = -1;	
		else
			dir[1] =rand(1);

		return dir;
	}
	
	/*
	 Handles the robot animation
	*/
	animation()
	{	
		// Input lag to the robots movement
		if(this.sec<3){ 
			this.sec++;
			return;
		}

		let currentBlock = control.getPassiveObject(this.x,this.y);

		//If the current block is a block destroyed
		// the robot gets stuck
		if(currentBlock.destroyed){
			this.getOutOfHoleWhenTrapped();
			return;
		}
		// Resets lag
		this.sec = 0;

		// If the robot was trapped before
		// Stops from falling to the same hole
		if(this.wasTrapped){
			this.wasTrapped = false;
		}else if(this.actorFall()){
			return;
		}

		let [dx, dy] = this.getHeroDir();

		//If the previous movement was in the vertical
		// moves in the horizontal
		// if horizontal
		// then vertical
		if(!this.alt){
			super.animation(dx,0);
			this.alt=!this.alt;
		}else{
			super.animation(0,dy);
			this.alt=!this.alt;
		}
	}
	resetTimeTodropGold(){
		this.FoodTimer = rand(this.timeToDropFood);
	}

	/*
	Tries to collect something
	*/
	collect(x,y){

		
		let nextBlock = control.getPassiveObject(x,y);
		let nextActiveBlock = control.getActiveObject(x,y);
		//If the Block is an hero
		if(nextActiveBlock != empty && nextActiveBlock.good)
		{
			control.gameLost();
		// If the next block is eatable
		} else if(nextBlock.eatable){

		if(this.tempFood==null){

			this.tempFood = nextBlock;
			this.tempFood.eaten();
			this.FoodTimer = 0;
			this.show();
			this.resetTimeTodropGold();
			}
		}
	}
}



class GameControl {
	constructor() {
		control = this;
		this.key = 0;
		this.time = 0;
		this.ctx = document.getElementById("canvas1").getContext("2d");
		empty = new Empty();	// only one empty actor needed
		
		
		control.hearts = 3;
		// Holds the number of golds in the map
		this.food = 0;
		// Holds the current level
		this.level=2;
		// Holds the number of golds eaten
		this.gold = 0;
		// Holds the ladders
		this.invisibleLadders = [];
		this.boundary = new Boundary();
		
		// Holds the gold labels
		this.goldLabel = null;
		this.goldLeftLabel = null;
		this.getGoldLabel();

		this.world = this.createMatrix();
		this.worldActive = this.createMatrix();
		this.loadLevel(this.level);
		this.setupEvents();
	}
	
	createMatrix() { // stored by columns
		let matrix = new Array(WORLD_WIDTH);
		for( let x = 0 ; x < WORLD_WIDTH ; x++ ) {
			let a = new Array(WORLD_HEIGHT);
			for( let y = 0 ; y < WORLD_HEIGHT ; y++ )
				a[y] = empty;
			matrix[x] = a;
		}
		return matrix;
	}

	loadLevel(level) {
		if( level < 1 || level > MAPS.length )
			fatalError("Invalid level " + level)
		let map = MAPS[level-1];  // -1 because levels start at 1
		for(let x=0 ; x < WORLD_WIDTH ; x++)
			for(let y=0 ; y < WORLD_HEIGHT ; y++) {
				let actorK = GameFactory.actorFromCode(map[y][x], x, y);
				if(!actorK.visible){
					control.invisibleLadders.push(actorK);
				}
			}
			this.PrintLevel();
			this.showLife();
			
	}
	
	getKey() {
		let k = control.key;
		control.key = 0;
		switch( k ) {
			case 37: case 79: case 74: return [-1, 0]; //  LEFT, O, J
			case 38: case 81: case 73: return [0, -1]; //    UP, Q, I
			case 39: case 80: case 76: return [1, 0];  // RIGHT, P, L
			case 40: case 65: case 75: return [0, 1];  //  DOWN, A, K
			case 0: return null;
			default: return String.fromCharCode(k);
		// http://www.cambiaresearch.com/articles/15/javascript-char-codes-key-codes
		};	
	}
	setupEvents() {
		addEventListener("keydown", this.keyDownEvent, false);
		addEventListener("keyup", this.keyUpEvent, false);
		setInterval(this.animationEvent, 1000 / ANIMATION_EVENTS_PER_SECOND);
	}

	keyDownEvent(k) {
		control.key = k.keyCode;
	}
	keyUpEvent(k) {
	}

	//Checks if the object is in the canvas
	static ObjectInCanvas(x,y)
	{
		if(x < 0 || x >= WORLD_WIDTH)
			return false;
		if(y < 0 || y >= WORLD_HEIGHT)
			return false;
		
		return true;
	}
	// Returns an object in a matrix
	getObject(x,y)
	{
		if(!GameControl.ObjectInCanvas(x,y))
			return this.boundary;
		else
	return control.worldActive[x][y] != empty ? control.worldActive[x][y] : control.world[x][y];
	}
	// Returns an active object
	getActiveObject(x,y)
	{
		if(!GameControl.ObjectInCanvas(x,y))
			return this.boundary;
		else
			return control.worldActive[x][y];
	}
    // Returns a passive Object
	getPassiveObject(x,y)
	{
		if(!GameControl.ObjectInCanvas(x,y))
			return this.boundary;
		else
			return control.world[x][y];
	}

	// Cleans the matrix
	// and invisible ladders
	cleanMatrixes()
	{
		for(let x=0 ; x < WORLD_WIDTH ; x++){
			for(let y=0 ; y < WORLD_HEIGHT ; y++) {
				this.world[x][y].hide();
				this.worldActive[x][y].hide();
			}
		}
		while(this.invisibleLadders.length>0){
			this.invisibleLadders.pop();
		}
	}

	createWorlds(){
		this.world = this.createMatrix();
		this.worldActive = this.createMatrix();
	}


	// Gets gold labels in the html
	getGoldLabel()
	{
			this.goldLabel = document.getElementById("goldLabel");
			this.goldLeftLabel = document.getElementById("goldLeftLabel");
	}
	// Prints the gold in the html
	printGold()
	{
		this.goldLabel.value = this.gold + hero.gold;
		this.goldLeftLabel.value = this.food;
	}

	// Prints the level in html
	PrintLevel()
	{
			let levelLabel = document.getElementById("levelLabel");
			levelLabel.value = this.level;
			let levelLeft = document.getElementById("levelLeft");
			levelLeft.value = MAPS.length;
	}


	// Prints the remaing lives in the html
	showLife(){
		let lg = document.getElementById('lg');
		lg.value = control.hearts;
	}

	// In case of losing 
	gameOver()
	{
		control.stop = false;
		control.lost = false;
		control.hearts--;
		control.food = 0;
		if(control.hearts <=0)
		{
			alert("Game Over!");
			location.reload();
		} else
		{
			mesg(`TRY AGAIN! ONLY ${control.hearts} LEFT! MAY GOD BE WITH YOU`);
			this.reloadGame();
		}
	}

	// Reloads the game
	reloadGame()
	{
		this.cleanMatrixes();
		this.createWorlds();
		this.loadLevel(control.level);

	}

	// Check if all the gold is eaten
	checkGoldCollected()
	{
		if(control.food==0 && !control.won){
			let size = control.invisibleLadders.length;

			for (let index = 0; index < size; index++) {
				control.invisibleLadders[index].makeVisible();
			}
			control.won = true;
		}
	}
		// IN case the game was won
		levelWon()
		{
			this.gold += hero.gold;
			control.won = false;
			hero.hide();

			control.level++;
			if(control.level>MAPS.length)
			{
				alert("Game Won!");
				control.level = 1;
				control.hearts = 2;
			}
			this.reloadGame();
		}
		
		// Checks if the winning conditions are met
		checkWinCondition()
		{
			if(hero.y == 0 && this.getPassiveObject(hero.x,hero.y).winObject 
			&& control.food == 0)
			{
				return true;
			}
			return false;
		}
	

	// Tells the engine the game is over
	gameLost()
	{
		control.lost = true;
		control.stop = true;
	}

	animationEvent() {
		control.time++;
		control.printGold();

			for(let x=0 ; x < WORLD_WIDTH && !control.stop; x++)
			for(let y=0 ; y < WORLD_HEIGHT && !control.stop; y++) {
				let a = control.worldActive[x][y];
				if( a.time < control.time ) {
					a.time = control.time;
					a.animation();
				}
			}
			
		control.checkGoldCollected();

		if(control.checkWinCondition())
			control.levelWon();
		 else if(control.lost)
			control.gameOver();
	}
	
}


// HTML FORM

function onLoad() {
  // Asynchronously load the images an then run the game
	GameImages.loadAll(function() { new GameControl(); });
}

// Resets the level
function b1() 
{ 
	mesg("Level Restarted!");
	control.food = 0;
	control.cleanMatrixes();
	control.createWorlds();
	control.loadLevel(control.level);
}

// teleports the hero to a random location
function b2() {
	hero.hide();
	hero.findRandomPos(hero);
	hero.show();
}


// Gives a random map
// Clears stats
function b3() {
	let newlevel = rand(MAPS.length);
	newlevel++; // To never be level 0

	// Resets all stats
	control.hearts = 3;
	control.food = 0;
	control.gold = 0;

	control.level = newlevel;
	control.reloadGame();
}


